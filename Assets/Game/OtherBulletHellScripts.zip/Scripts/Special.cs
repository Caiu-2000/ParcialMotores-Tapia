public abstract class Special
{

}